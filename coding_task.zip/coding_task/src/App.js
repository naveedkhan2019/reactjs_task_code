import './App.css';
import Menu from './Menu';
import {BrowserRouter as Router,Route ,Switch} from 'react-router-dom';
import Home from './Home';
import Details from './Details';

function App() {
  
  return (
    <Router>
      <div className="App">
         <Menu />
        <div className="content">
          <Switch>

            <Route exact path="/">
               <Home />
            </Route>
            <Route exact path="/details/:id">
                <Details />
            </Route>

          </Switch>
          
        </div>

      </div>
    </Router>
  );
}

export default App;
