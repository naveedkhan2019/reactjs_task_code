import { useEffect } from "react";
import { useParams } from "react-router";
import { useState } from "react/cjs/react.development";

const Details = () => {
    const {id}= useParams();
    const url = "https://api.spacexdata.com/v3/launches?flight_number="+id;
    let [Launchdata, setLaunchdata ]= useState(null);

    useEffect(()=>{
        fetch(url)
        .then(res=>{
            return res.json();
        })
        .then(data=>{
            console.log(data);
            Launchdata = data[0];
            setLaunchdata(data[0]);
        })
        .catch(error=>{
                console.log(error)
                
            });

    },[url]);

    return ( 
        <div className="details">
            
            
              { Launchdata &&
                    <div>
                        <h1>Launch Flight Id:{Launchdata.flight_number}</h1>
                        <p>{Launchdata.details} </p>
                        <p>Mission Name: {Launchdata.mission_name}</p>
                        <p>Launch Date: {Launchdata.date_unix}</p>
                    </div>
                }   
        </div>
     );
}
 
export default Details;