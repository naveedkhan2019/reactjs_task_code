import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
//import useFetch from "./useFetch";

const Home = () => {
    //https://api.spacexdata.com/v3/launches?limit=1&offset=5
    const [url, setUrl] = useState("https://api.spacexdata.com/v3/launches?limit=10&offset=1");
    //const [isRequestPending, setIsRequestPending] = useState(true);
    const [Launches, setLaunches] = useState(null);
    const [Rockets, setRockets] = useState(null);
    const currentList = "Rockets";

   // const [data, setData] = useState(null);
    const [isPending, setIsPending] = useState(true);
   // const [Error, setError] = useState(null);

   // const {data, isPending, Error} = useFetch(url);
    
        useEffect(()=>{
            fetch(url)
            .then(res=>{
                return res.json();
            })
            .then(data=>{
                console.log(data);
                if(currentList=="Launches"){
                    setRockets(data);
                    currentList = "Rockets";
                }
                else{
                    setLaunches(data);
                    currentList = "Launches";
                }
                
                
                setIsPending(false);
            })
            .catch(error=>{
                    console.log(error)
                    
                });
    
        },[url]);
      

   

    return ( 

        <div className="home">

            {Launches && <h1>List Of Launches</h1>}
            {Rockets && <h1>List Of Rockets</h1>}
            

            {Launches && Launches.map((launch)=>(
               <Link to={`/details/${launch.flight_number}`}> 
                    <div>
                        <h1>Launch Flight Id:{launch.flight_number}</h1>
                        <p>{launch.details} </p>
                    </div>
              </Link>
            ))}
            <div>
                <h2></h2>
                <p></p>
            </div>

        </div>

     );
}
 
export default Home;