const Menu = () => {
    return ( 
        <div className="navBar">
            <button>Rockets</button>
            <button>Launches</button>
        </div>

     );
}
 
export default Menu;